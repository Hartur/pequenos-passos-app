# Pequenos Passos — planos e limites

Este documento define os planos, os limites de uso, as regras de transição entre eles e as formas de obter os próprios dados. Ele é a fonte de verdade para essas regras; os demais documentos apenas fazem referência a ele. A aplicação técnica no servidor está na [especificação da API](../../backend-api/docs/especificacao.md).

## 1. Planos

| | Gratuito sem conta | Gratuito com conta | Premium |
|---|---|---|---|
| Onde é usado | Somente aplicativo Android | Aplicação web e aplicativo Android | Aplicação web e aplicativo Android |
| Conexão | Offline | Online, com uso offline no Android e sincronização posterior | Online, com uso offline no Android e sincronização posterior |
| Onde os dados ficam | Somente no aparelho | No servidor, com cópia local no Android | No servidor, com cópia local no Android |
| Hábitos ativos | 1 | 1 | Até 30 |
| Registros por hábito por dia | 1 | 1 | Até 5 |
| Relatório simples na página de acompanhamento | Sim | Sim | Sim |
| Relatórios avançados | Não | Não | Sim |
| Solicitação de dados pela LGPD (CSV) | Não se aplica: os dados não saem do aparelho | Sim | Sim |
| Backup e importação (JSON criptografado) | Não | Não | Sim |

O relatório simples mostra, por dia, se o hábito foi realizado, parcialmente realizado, não realizado ou ficou sem registro. Relatórios avançados (por exemplo, evolução de metas, tempo de prática acumulado e comparação entre hábitos) serão detalhados quando a etapa for priorizada no [roadmap](../roadmap.md).

A primeira versão é a aplicação web com a API; o modo sem conta chega com o aplicativo Android. Até a etapa de pagamentos reais do roadmap, a contratação do premium usa pagamento simulado, sempre aprovado e sem cobrança.

## 2. Por que existem limites

Os limites diferenciam os planos e também protegem o serviço contra uso abusivo, como a criação em massa de hábitos e registros para encher o banco de dados. Por isso:

- Os limites são aplicados pelo servidor, e não apenas pelas interfaces. Uma requisição que ultrapasse um limite é recusada mesmo que tenha sido enviada fora dos aplicativos oficiais.
- O aplicativo Android aplica os mesmos limites no modo sem conta, para que o comportamento seja igual em todos os planos gratuitos.
- Além dos limites de plano, o serviço limita a quantidade de requisições por conta e por origem e o tamanho dos campos de texto. Os valores ficam na especificação da API.

A hipótese é que 30 hábitos e 5 registros por hábito por dia sejam suficientes para praticamente todos os usuários. Isso deve ser acompanhado nas métricas.

## 3. Como os limites são contados

- **Hábito ativo:** hábito não arquivado. Hábitos arquivados pela própria pessoa não contam no limite de ativos, permanecem disponíveis para consulta e não aceitam novos registros.
- **Hábito ocultado:** hábito não escolhido na mudança do premium para o gratuito. Não aparece nas telas, não conta no limite e não pode ser reativado no gratuito (ver [cancelar ou deixar expirar o premium](#cancelar-ou-deixar-expirar-o-premium)).
- **Registro:** uma realização ou declaração de resultado (realizado, parcialmente realizado ou não realizado) de um hábito em uma data.
- **Data do registro:** o dia em que a atividade ocorreu, no fuso horário do usuário, e não o momento em que o registro foi enviado ao servidor.
- **Corrigir ou complementar** um registro existente (status, quantidade, duração, observação) não cria um novo registro e não consome o limite.
- **Excluir** um registro libera a vaga daquele dia.
- **Adiar** um lembrete não cria registro.
- **Ausência de registro** não conta como falha nem aparece como falha nos relatórios.

Quando um limite é atingido, a interface explica o limite de forma neutra, sem culpa nem pressão, e indica que o premium amplia esse limite. A mensagem não deve impedir o uso do que já está disponível.

> **Ponto aberto:** além do limite de hábitos ativos, pode ser necessário um teto para o total de hábitos armazenados (ativos e arquivados), para evitar o abuso por arquivamento repetido. O valor deve ser definido antes da implementação da API.

## 4. Transições entre planos

### Criar conta a partir do modo sem conta

*Decisão de proposta, a validar.*

1. A pessoa cria a conta ou entra em uma conta existente pelo aplicativo Android.
2. O aplicativo pergunta se ela quer levar para a conta o hábito e os registros que estão no aparelho.
3. Se aceitar, os dados locais são enviados para a conta sem perder histórico nem duplicar registros.
4. Se a conta já tiver um hábito ativo (por exemplo, criado pela web) e o limite do plano não permitir os dois, a pessoa escolhe qual fica ativo. O outro é arquivado, sem perda de dados.
5. Se recusar, os dados locais continuam no aparelho, mas o aplicativo passa a mostrar os dados da conta. A interface explica essa escolha antes da confirmação.

### Sair da conta no aplicativo Android

*Decisão de proposta, a validar.*

Os dados da conta permanecem no servidor e continuam acessíveis pela web. O aparelho remove a cópia local dos dados da conta e volta ao modo sem conta. Antes de sair, o aplicativo avisa sobre registros ainda não sincronizados e oferece sincronizá-los.

### Assinar o premium

Os limites do premium passam a valer imediatamente em todas as plataformas. Hábitos ocultados por um cancelamento anterior, se ainda estiverem guardados, voltam a aparecer como arquivados e deixam de ter remoção agendada. Hábitos arquivados podem ser reativados até o limite de 30.

### Cancelar ou deixar expirar o premium

1. Ao cancelar, o premium continua valendo até o fim do período já contratado. A mudança para o gratuito acontece nessa data.
2. Depois da mudança, a pessoa **precisa escolher 1 hábito** para seguir antes de continuar usando o produto. A tela de escolha explica, de forma neutra, o que acontece com os demais.
3. A escolha é **definitiva** enquanto a pessoa estiver no gratuito: não é possível trocar o hábito escolhido por um dos outros nem alternar entre eles.
4. Os demais hábitos são **ocultados**: não aparecem em nenhuma tela, nem como arquivados, e não aceitam registros. Eles ficam guardados por **3 meses** a partir da mudança para o gratuito.
5. Depois desses 3 meses, os hábitos ocultados e todos os seus registros são **removidos definitivamente** da base de dados.
6. O hábito escolhido mantém todo o histórico, inclusive os dias passados com mais de um registro. A partir da mudança, vale o limite de 1 registro por dia.
7. Assinar novamente antes da remoção cancela a remoção agendada e devolve os hábitos ocultados, que podem ser reativados até o limite do premium.
8. Enquanto estiverem guardados, os hábitos ocultados fazem parte dos dados da pessoa e são incluídos na [solicitação de dados pela LGPD](#solicitação-de-dados-pela-lgpd).

*Decisões de proposta, a validar:*

- **Escolha não feita:** enquanto a pessoa não escolher, ela vê apenas a tela de escolha e não consegue registrar. Se não escolher até o fim dos 3 meses, o hábito com o registro mais recente é mantido e os demais são removidos.
- **Avisos:** a tela de escolha e a área de assinatura informam quantos hábitos estão guardados e até quando, sem listá-los. Um e-mail é enviado 30 dias e 7 dias antes da remoção. Os avisos explicam como assinar novamente e como solicitar os dados pela LGPD, sem tom de pressão ou culpa.

A ocultação e a remoção afetam apenas os hábitos não escolhidos na mudança de plano. Elas não são uma penalidade por pausas: o hábito escolhido nunca é removido por falta de registro.

## 5. Obter os próprios dados

Existem duas formas, com finalidades diferentes. Uma não substitui a outra.

### Solicitação de dados pela LGPD

- Disponível para toda pessoa com conta, em qualquer plano, inclusive após o cancelamento do premium.
- Atende ao direito de acesso do titular. Os dados são entregues em **CSV**, legível em planilhas e outros programas.
- Inclui os dados de conta e perfil, o estado do plano e da assinatura, os hábitos (ativos e arquivados), o histórico de metas e todos os registros.
- O arquivo é apenas para consulta: **não pode ser importado** de volta no Pequenos Passos.
- *Proposta:* a solicitação é feita na tela Mais; o arquivo fica disponível para download por tempo limitado.
- O procedimento deve ser confirmado com orientação jurídica antes da abertura das contas ao público, inclusive quanto ao atendimento da portabilidade.

### Backup e importação (premium)

- O backup exporta os hábitos e registros em um arquivo **JSON com conteúdo criptografado**.
- Somente o backend do Pequenos Passos consegue ler e importar o arquivo. A pessoa não consegue lê-lo nem alterá-lo; arquivos alterados são recusados na importação.
- A importação respeita os limites do plano e não duplica hábitos ou registros que já existam na conta.
- Exportar e importar backups são recursos premium.
- *Proposta:* o backup só pode ser importado na mesma conta que o gerou.

Independentemente do plano, a pessoa pode consultar e excluir seus registros e excluir a conta com todos os dados.

## 6. Fora deste documento

Preços, meios de pagamento reais e periodicidade da assinatura ainda não estão definidos. As hipóteses comerciais estão na [visão do produto](../product-spec.md#5-monetização-proposta-e-hipóteses).
