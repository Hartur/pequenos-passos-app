# Pequenos Passos — telas e interações

Este documento registra as decisões de produto feitas para o protótipo visual. Ele define o conteúdo e os estados das telas, comuns ao aplicativo Android e à aplicação web. A disposição visual de cada plataforma (navegação, tamanhos de tela, gestos) fica na documentação da própria aplicação: [android-app](../../android-app/AGENTS.md) e [especificação da web](../../web-app/docs/especificacao.md). A especificação de notificações continua sendo a fonte de verdade para lembretes e registro rápido, e [planos e limites](planos-e-limites.md) é a fonte de verdade para quantidades permitidas em cada plano.

## Escopo e estados futuros

Conta e assinatura premium fazem parte da primeira versão (API e web). Até a etapa de pagamentos reais do roadmap, a contratação usa pagamento simulado, e a tela de contratação informa claramente que nenhuma cobrança é feita. Os estados de sincronização chegam com o aplicativo Android.

O estado sem conta existe apenas no aplicativo Android; a aplicação web exige conta. Nesse estado, o aplicativo apresenta um hábito ativo. A tela explica de forma breve que criar uma conta gratuita permite acompanhar o hábito também pela web e em outros aparelhos, e que o premium permite acompanhar mais hábitos. A mensagem não deve sugerir que os dados locais estejam protegidos por sincronização enquanto não houver conta.

## Navegação principal

A navegação principal reúne quatro destinos: **Hoje**, **Hábitos**, **Registros** e **Mais**. Ela destaca o destino atual e preserva o contexto ao trocar de tela. No Android, a navegação é inferior; na web, a forma de navegação depende do tamanho da tela.

## Hoje

A tela Hoje mostra somente os hábitos agendados para o dia em foco, com nome, meta ou duração, horário quando existir e o estado do registro. A tela não interpreta ausência de registro como falha.

### Com conta

- Exibe foto ou avatar, cumprimento e nome da pessoa.
- Mostra a data, o seletor de dia e o resumo dos hábitos concluídos entre os hábitos planejados.
- Lista os hábitos programados para o dia: um no plano gratuito, vários no premium.
- Cada item permite reconhecer a categoria por cor e ícone e informa se está concluído, parcial ou ainda sem registro.
- No premium, quando o hábito admite mais de um registro por dia, o item mostra quantos registros já foram feitos no dia.

### Sem conta

- Não exibe foto, cumprimento ou nome de perfil.
- Exibe somente o hábito ativo permitido nesse estado.
- Mostra um convite curto para criar uma conta e acompanhar o hábito em qualquer lugar. O convite não interrompe o registro do hábito já existente.

## Hábitos

A tela Hábitos lista os hábitos cadastrados e oferece adicionar, editar e iniciar a remoção de vários itens. Quando o limite de hábitos ativos do plano for atingido, a ação de adicionar explica o limite de forma neutra, em vez de simplesmente desaparecer. Hábitos arquivados pela própria pessoa ficam acessíveis para consulta, separados dos ativos. Hábitos ocultados pelo fim do premium não aparecem nesta tela nem em nenhuma outra, conforme [planos e limites](planos-e-limites.md#cancelar-ou-deixar-expirar-o-premium).

## Escolha do hábito após o fim do premium

Quando o período pago termina após um cancelamento, a pessoa vê esta tela antes de qualquer outra e só segue depois de escolher.

- Lista os hábitos que eram ativos no premium, com nome, categoria e último registro, para ajudar na escolha.
- Permite selecionar um único hábito e pede confirmação, explicando que a escolha não poderá ser trocada enquanto a conta estiver no gratuito.
- Informa, sem tom de pressão ou culpa, que os demais hábitos deixarão de aparecer, ficarão guardados por 3 meses e serão removidos depois disso, a menos que a pessoa assine novamente.
- Oferece assinar novamente e solicitar os dados pela LGPD.

### Edição rápida no card

Cada card mostra e permite ajustar rapidamente:

- dias da semana em que o hábito deve ser realizado;
- duração ou meta de tempo;
- ação de editar os detalhes;
- ação de remover o hábito.

### Remoção de vários hábitos

Ao selecionar **Remover vários**, os cards passam para o modo compacto e escondem os controles de edição rápida. A seleção ocorre ao tocar ou clicar no próprio card, sem checkbox ou radio button.

- Um item selecionado recebe fundo cinza claro e o seu nome fica riscado.
- A tela informa a quantidade de itens selecionados e mantém uma ação para cancelar o modo.
- Enquanto não houver seleção, não há ação de exclusão disponível.
- Ao selecionar pelo menos um item, aparece uma ação flutuante **Excluir _n_ hábitos**. A exclusão efetiva deve pedir confirmação antes de remover dados.

## Registros

A tela Registros oferece um gráfico em períodos semanais, mensais ou anuais. A visão semanal é o estado inicial.

Os gráficos mostram a frequência de registros por hábito e mantêm uma legenda distinguindo registrado, parcialmente realizado e sem registro. Dias sem registro não podem ser incluídos em contagens de falha nem receber linguagem punitiva.

Esse acompanhamento por dia é o relatório simples, disponível em todos os planos. Relatórios avançados, quando existirem, aparecem nesta tela apenas para o premium.

## Mais

A tela Mais agrupa preferências de perfil e informações do plano:

- perfil: alterar nome, senha e foto;
- assinatura: informar se está ativa, até quando vale ou se a pessoa está no plano gratuito; assinar e cancelar o premium; após o fim do premium, informar quantos hábitos estão guardados e até quando, sem listá-los;
- sincronização (somente Android): informar o estado atual, como sincronizado, pendente, indisponível ou sem conta;
- backup: gerar e importar backup, disponível no premium;
- meus dados: solicitar os dados pela LGPD em CSV, disponível para qualquer conta;
- conta: sair da conta e excluir a conta com todos os dados.

Sem conta, a tela explica que os dados permanecem somente no aparelho e oferece criar uma conta ou entrar em uma existente. Estados de assinatura e sincronização precisam representar o estado real do serviço quando forem implementados.
