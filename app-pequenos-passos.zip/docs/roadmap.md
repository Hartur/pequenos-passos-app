# Pequenos Passos — roadmap e escopo

Este documento organiza a sequência de trabalho das três aplicações (API backend, web e Android) e distingue a visão futura do escopo a implementar. A visão completa e as hipóteses do produto estão em [product-spec.md](product-spec.md); os planos e limites estão em [planos e limites](produto/planos-e-limites.md). Critérios específicos do incremento de notificações ficam em [MVP de notificações e registro rápido](../android-app/docs/planejamento/mvp-notificacoes-e-registro-rapido.md).

## Princípio de priorização

Construir o produto incrementalmente, priorizando simplicidade, confiabilidade, privacidade e validação com usuários reais. A primeira versão é a API com a aplicação web, porque pode ser desenvolvida em qualquer máquina, sem as ferramentas do Android. O aplicativo Android vem em seguida e, desde a sua primeira versão, deve funcionar offline sem conta. A presença de uma ideia na visão do produto não a autoriza para implementação. Antes de cada tarefa, confirme o estágio e os critérios aplicáveis neste roadmap e nos documentos vinculados.

## Sequência de etapas

1. **Refinamento da ideia:** definir público, problema, proposta de valor e diferencial. Resultado: visão e hipóteses prioritárias.
2. **Pesquisa científica aplicada:** organizar estudos, limitações e regras que possam orientar o produto. Resultado: biblioteca inicial fundamentada.
3. **Validação com usuários:** entrevistar potenciais usuários e testar entendimento. Resultado: evidências qualitativas de utilidade e necessidades.
4. **Definição do MVP:** selecionar cadastro, registros, calendário, histórico, progresso e sugestões básicas. Resultado: especificação funcional e critérios de aceitação.
5. **Protótipo visual:** desenhar telas e testar fluxos. As decisões de estados e interações das telas ficam em [telas e interações](produto/telas-e-interacoes.md). Resultado: protótipo navegável.
6. **Preparação técnica da API e da web:** configurar os projetos conforme o [backend-api](../backend-api/AGENTS.md) e o [web-app](../web-app/AGENTS.md), incluindo banco de dados, migrações, testes e ambiente de execução. Resultado: projetos executáveis, ainda sem dados reais de usuários.
7. **Versão inicial da API e da web:** cadastro, autenticação, exclusão de conta, hábitos e registros com os limites do gratuito e do premium, relatório simples, assinatura premium com **pagamento simulado** que sempre é aprovado, e solicitação de dados pela LGPD em CSV. Resultado: produto utilizável pelo navegador, com os dois planos.
8. **Testes com usuários:** observar frequência, dificuldades, utilidade das sugestões e interesse pelo premium. Resultado: melhorias priorizadas.
9. **Preparação técnica do Android:** configurar o projeto conforme o [android-app](../android-app/AGENTS.md). Resultado: projeto executável com persistência local.
10. **Versão inicial do Android:** modo sem conta offline, modo com conta sincronizado com a API, migração do modo sem conta para a conta e notificações com registro rápido. Resultado: o mesmo hábito acompanhado pelo Android e pela web, e o uso offline sem conta.
11. **Recursos premium adicionais:** backup e importação em JSON criptografado e relatórios avançados. Resultado: premium completo, ainda com pagamento simulado.
12. **Validação comercial:** testar benefícios premium e disposição para pagar. Resultado: evidências iniciais de monetização.
13. **Pagamentos reais:** substituir o pagamento simulado por provedores reais, somente após validar o modelo comercial e autorizar essa etapa. Resultado: assinatura premium cobrada.
14. **Publicação e evolução:** publicar, acompanhar retenção e avaliações e evoluir com base em evidências.

*A posição da etapa 11, entre o Android e a validação comercial, é uma proposta a validar.*

### Pagamento simulado

Até a etapa 13, a contratação do premium sempre termina como paga, sem cobrança real. Enquanto isso:

- A interface informa claramente que nenhuma cobrança é feita.
- O pagamento simulado fica isolado atrás de um ponto único da API, para ser trocado pelo provedor real sem alterar as regras de plano.
- Se a web for aberta ao público nesse período, qualquer pessoa poderá obter o premium sem pagar. Isso pode ser útil para observar interesse, mas não gera receita e deve ser uma decisão consciente antes da abertura.

## Incremento documentado: notificações e registro rápido

O incremento de notificações e registro rápido tem especificação de produto, restrições técnicas e critérios de aceitação próprios. Consulte os documentos listados no [índice de instruções](../AGENTS.md). Ele faz parte da etapa 10. O escopo inclui configuração e desativação de lembretes por hábito, ações na notificação, persistência local de cumprimento/não cumprimento, abertura opcional para complementação, adiamento sem registro e proteção contra duplicidade. A aceitação deve seguir a lista completa do documento de planejamento.

O documento de planejamento identifica a funcionalidade como candidata importante para a versão inicial do Android e prioriza primeiro o fluxo básico de notificação, registro e persistência local. Personalizações avançadas de horários, múltiplas notificações, estatísticas detalhadas e lembretes na web ficam para evolução posterior. Isso não autoriza, por si só, as etapas futuras deste roadmap.

## Fora do escopo sem nova autorização

- Aplicativo Android antes da etapa 9.
- Backup, importação e relatórios avançados antes da etapa 11.
- Pagamentos reais antes da etapa 13, mesmo que constem como hipóteses na visão.
- IA em tempo de execução.
- Personalizações avançadas de lembretes, múltiplas notificações, estatísticas detalhadas e lembretes na web.

Esses itens exigem etapa autorizada e critérios próprios antes da implementação. Decisões importantes de produto ou arquitetura ainda indefinidas e difíceis de reverter devem ser apresentadas com alternativas para orientação.
