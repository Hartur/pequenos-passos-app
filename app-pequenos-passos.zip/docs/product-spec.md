# Pequenos Passos — visão e especificação do produto

**Plataformas:** API backend e aplicação web (primeira versão) e aplicativo Android  
**Modelo comercial proposto:** freemium, com uso gratuito offline sem conta, uso gratuito online com conta e assinatura premium.

Este documento descreve a visão, os princípios, as funcionalidades planejadas, a fundamentação e as hipóteses do produto, independentemente de plataforma. O escopo autorizado para cada etapa está em [roadmap.md](roadmap.md). Planos, limites e regras de conta estão em [planos e limites](produto/planos-e-limites.md). As decisões de conteúdo e estados das telas estão em [telas e interações](produto/telas-e-interacoes.md). A especificação de lembretes e registro rápido está em [notificações e registro rápido](produto/notificacoes-e-registro-rapido.md).

Decisões técnicas de cada aplicação ficam na pasta da própria aplicação: [android-app](../android-app/AGENTS.md), [backend-api](../backend-api/AGENTS.md) e [web-app](../web-app/AGENTS.md).

## 1. Visão e proposta de valor

Pequenos Passos ajuda pessoas a começar pequeno, visualizar seu progresso e continuar evoluindo, mesmo quando a rotina não é perfeita. O usuário escolhe livremente o comportamento ou habilidade, define uma meta e acompanha sua evolução. O aplicativo ajuda a transformar objetivos abstratos em ações concretas, acompanhar a execução e sugerir próximos passos com base no histórico.

Os pilares são autonomia (o usuário escolhe hábitos e objetivos), simplicidade (registro com pouco esforço), orientação (sugestões informadas por pesquisas) e progresso visível (histórico, gráficos e marcos). O aplicativo não determina quais hábitos a pessoa deve ter. Exemplos incluem leitura, exercício, estudo, concentração, meditação, sono, idiomas, instrumentos, atividades pessoais e outros comportamentos escolhidos pelo usuário.

Com uma conta, os dados ficam disponíveis em qualquer lugar: a pessoa pode registrar pelo celular e acompanhar pelo navegador, inclusive no plano gratuito. Sem conta, o aplicativo Android continua útil e totalmente offline.

## 2. Princípios do produto

- O usuário pode cadastrar qualquer hábito; exemplos ajudam, mas não formam uma lista restritiva.
- Incentivar metas iniciais realistas e progressão gradual, sem impor aumentos.
- Distinguir realizado, parcialmente realizado, não realizado e sem registro. A falta de registro não equivale a falha confirmada.
- Interrupções não apagam o progresso. O produto pode apoiar a retomada, por exemplo sugerindo uma meta temporariamente menor ou mudança de contexto.
- Marcos e gamificação mostram acompanhamento, sem alegar que certa quantidade de dias forma um hábito ou certa quantidade de horas comprova expertise.
- Privacidade e autonomia: o usuário controla dados, lembretes e metas. Não usar mensagens culpabilizadoras nem penalizar pausas.
- Mudanças de plano não apagam dados de imediato. No fim do premium, a pessoa escolhe 1 hábito para seguir; os demais deixam de aparecer, ficam guardados por 3 meses para uma eventual nova assinatura e só então são removidos, com aviso prévio. O hábito escolhido nunca é removido por falta de registro.

## 3. Fundamentação científica e implicações

Repetição, automaticidade e desenvolvimento de habilidade são conceitos relacionados, mas distintos. O produto deve comunicar essa distinção e apresentar evidências como referências, não como garantias individuais.

### Formação de hábitos

A revisão sistemática e meta-análise *Time to Form a Habit: A Systematic Review and Meta-Analysis of Health Behaviour Habit Formation and Its Determinants* (2024) reuniu 20 estudos e 2.601 participantes. Em quatro estudos, as medianas variaram de 59 a 66 dias, as médias de 106 a 154 dias e houve grande variabilidade individual. Implicações: não prometer prazo universal e permitir acompanhamento prolongado. Fontes: [PubMed](https://pubmed.ncbi.nlm.nih.gov/39685110/) e [texto completo no PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11641623/).

Lally et al. (2010), em *How are habits formed: Modelling habit formation in the real world*, estimaram entre 18 e 254 dias para atingir 95% do nível assintótico de automaticidade entre participantes cujo modelo pôde ser ajustado. Uma oportunidade perdida não prejudicou materialmente a formação naquele contexto experimental. Implicações: apoiar contextos estáveis, evitar penalidades por falhas isoladas e facilitar retomadas. [DOI](https://doi.org/10.1002/ejsp.674).

### Habilidades e prática

Ericsson, Krampe e Tesch-Römer (1993), em *The Role of Deliberate Practice in the Acquisition of Expert Performance*, investigaram prática estruturada e direcionada à melhoria. A regra popular das 10.000 horas não é um prazo universal para expertise: domínio, qualidade da prática, feedback e diferenças individuais importam. Macnamara, Hambrick e Oswald (2014) encontraram diferenças relevantes entre domínios na proporção da variação de desempenho explicada pela prática deliberada. Implicações: registrar tempo de prática e metas pessoais, distinguindo prática acumulada de competência demonstrada. Fontes: [Ericsson et al.](https://doi.org/10.1037/0033-295X.100.3.363) e [Macnamara et al.](https://doi.org/10.1177/0956797614535810).

Não há prazo universal bem estabelecido após o qual um hábito necessariamente desapareça. O produto pode registrar interrupções e apoiar retomadas, mas não deve usar contagem regressiva para prever perda de hábito ou habilidade.

Revisões de intervenções digitais identificam automonitoramento, definição de metas, lembretes, feedback e personalização entre técnicas de mudança de comportamento. Isso orienta o produto, sem garantir resultados de uma implementação específica. Fontes: [JMIR (2024)](https://www.jmir.org/2024/1/e54375) e [Annals of Behavioral Medicine](https://academic.oup.com/abm/article/57/10/817/7251346).

## 4. Funcionalidades previstas

### Hábitos e registros

O cadastro poderá incluir nome, descrição, categoria opcional, frequência, meta inicial, unidade, contexto ou horário preferencial, data de início e lembretes opcionais. O registro poderá indicar realizado, realizado parcialmente ou não realizado, com possibilidade de corrigir registros anteriores. Ausência de registro permanece distinta de falha.

A quantidade de hábitos ativos e de registros por dia depende do plano; as regras estão em [planos e limites](produto/planos-e-limites.md).

As regras de apresentação e edição rápida dos hábitos, incluindo o modo de remoção múltipla, estão em [telas e interações](produto/telas-e-interacoes.md).

### Histórico e progresso

Calendário e histórico permitem consultar registros, padrões, interrupções e mudanças de metas. O painel poderá apresentar frequência, percentual nos dias elegíveis e registrados (com critérios transparentes), tempo de prática, evolução de metas, marcos e retomadas.

Todos os planos incluem um relatório simples na página de acompanhamento, mostrando os dias realizados, parcialmente realizados, não realizados e sem registro. Relatórios avançados são recurso premium.

A visualização de registros inicia pelo período semanal e distingue registro parcial de ausência de registro. Os detalhes de tela estão em [telas e interações](produto/telas-e-interacoes.md).

### Próximos passos e orientações

Um motor determinístico poderá sugerir manter a meta, aumentá-la gradualmente, reduzi-la temporariamente, rever horário/contexto, retomar por uma ação menor ou aguardar mais registros. Recomendações devem ser opcionais, justificadas e independentes da interface e da plataforma.

A biblioteca poderá abordar metas realistas, repetição em contextos estáveis, prática deliberada, planejamento de obstáculos, retomada e progressão gradual. Incluir fontes quando aplicável e explicitar limitações.

### Lembretes e gamificação

Lembretes ficam sob controle do usuário. Os fluxos e critérios estão especificados exclusivamente no [documento de notificações](produto/notificacoes-e-registro-rapido.md). No início, lembretes existem apenas no aplicativo Android; lembretes na aplicação web são evolução posterior.

Gamificação poderá incluir marcos de consistência, calendário, gráficos, tempo de prática, progresso até metas, reconhecimento de retomadas e histórico de evolução. Marcos como 30 ou 60 dias são objetivos de acompanhamento, não prazos científicos universais. Metas de prática como 10, 50, 100 ou 500 horas não representam níveis comprovados de expertise.

### Dados da pessoa: LGPD e backup

Há duas formas de obter os próprios dados, detalhadas em [planos e limites](produto/planos-e-limites.md#5-obter-os-próprios-dados):

- **Solicitação pela LGPD:** para qualquer conta, em CSV legível, somente para consulta; não pode ser importada no produto.
- **Backup e importação (premium):** arquivo JSON com conteúdo criptografado, que somente o backend do Pequenos Passos consegue ler e importar.

## 5. Monetização proposta e hipóteses

O modelo proposto é freemium: versão gratuita útil, com ou sem conta; premium para valor adicional concreto. Os planos e seus limites estão definidos em [planos e limites](produto/planos-e-limites.md).

Resumo:

- **Gratuito sem conta:** 1 hábito, 1 registro por dia, dados somente no aparelho Android, offline.
- **Gratuito com conta:** 1 hábito, 1 registro por dia, dados no servidor e acesso simultâneo pela web e pelo Android.
- **Premium:** até 30 hábitos, até 5 registros por hábito por dia, relatórios avançados, backup e importação.

Até a etapa de pagamentos reais do [roadmap](roadmap.md), a contratação do premium usa pagamento simulado, sempre aprovado e sem cobrança.

Os limites cumprem dois papéis: diferenciar os planos e proteger o serviço contra uso abusivo, como o preenchimento intencional do banco de dados. A hipótese é que 30 hábitos atendam praticamente todos os usuários; isso deve ser observado nas métricas.

Como a conta gratuita já oferece continuidade entre dispositivos, o diferencial do premium passa a ser a quantidade de hábitos, a granularidade dos registros, os relatórios avançados e a guarda dos dados (backup e importação). Jornadas guiadas são possibilidade posterior.

Assinaturas mensal e anual são opções a avaliar; preços não estão definidos. R$ 7,90–12,90 por mês e anual equivalente a aproximadamente 8–10 mensalidades são apenas hipóteses de pesquisa, não preços definidos ou aceitos. Validar disposição para pagar, taxas de lojas e pagamentos, impostos, infraestrutura, armazenamento, suporte, aquisição, cancelamento e margem sustentável. Desconto anual deve preservar margem. O custo de manter contas gratuitas online também deve entrar nessa conta.

## 6. Plataformas e dados conceituais

O produto é composto por três aplicações, cada uma com suas decisões técnicas documentadas na própria pasta:

- **[android-app](../android-app/AGENTS.md):** aplicativo nativo; funciona offline sem conta e, com conta, sincroniza com a API.
- **[backend-api](../backend-api/AGENTS.md):** API que guarda os dados das contas, aplica os limites dos planos e atende o Android e a web.
- **[web-app](../web-app/AGENTS.md):** aplicação web para usuários com conta, sempre online.

Não é necessária IA em tempo de execução no MVP. IA poderá apoiar pesquisa/síntese, sempre com revisão das fontes originais.

Estruturas conceituais previstas (a refinar durante desenvolvimento), compartilhadas entre as aplicações:

- **Habit:** id, nome, descrição, categoria, unidade, meta, frequência, contexto, início e arquivamento.
- **HabitLog:** id, hábito, data, status, quantidade realizada, duração, observação e origem.
- **HabitGoalHistory:** histórico de metas e vigências.
- **Strategy:** orientações e referências.
- **RecommendationRule:** regras de recomendação.
- **Milestone:** marcos pessoais e conquistas.
- **PracticeSession:** sessões e duração.
- **UserAccount:** conta, plano e preferências.
- **Subscription:** estado da assinatura premium.
- **SyncMetadata:** controle de sincronização entre aparelho e servidor.

A sincronização deve prever autenticação segura, identidade de registros, sincronização incremental, concorrência e conflitos, modo offline, exclusão de conta e dados, proteção em trânsito e repouso e recuperação de falhas, preservando histórico e evitando duplicações.

## 7. Métricas e responsabilidade

Métricas a acompanhar: ativação (cadastro e primeiro registro), criação de conta a partir do modo offline, uso simultâneo de Android e web, retenção, frequência de registro, utilidade percebida das recomendações, retomada após interrupções, marcos, conversão para premium, quantidade de hábitos usada por pagantes, cancelamentos, receita recorrente, custo de infraestrutura por conta gratuita e por pagante e margem após taxas, impostos e custos. Métricas devem distinguir falta de registro de abandono confirmado.

Coletar somente o necessário; permitir consultar e excluir registros; não compartilhar sem consentimento; proteger dados armazenados no servidor; explicar limitações das recomendações; não transformar estimativas em garantias; e deixar metas e notificações sob controle do usuário. Contas online exigem política de privacidade clara, segurança e procedimentos de exclusão de conta e dados.

A LGPD garante ao titular, entre outros direitos, acesso aos próprios dados e portabilidade. Por isso, a solicitação de dados em CSV está disponível em qualquer plano, separada do backup premium. A ocultação e a remoção, 3 meses depois, dos hábitos não escolhidos no fim do premium também devem constar na política de privacidade. Esses pontos devem ser confirmados com orientação jurídica antes da abertura das contas ao público.

## 8. Diretrizes estabelecidas e hipóteses

Diretrizes estabelecidas: primeira versão com API backend e aplicação web, incluindo premium com pagamento simulado; Android em seguida, com modo offline sem conta; no fim do premium, escolha definitiva de 1 hábito e remoção dos demais após 3 meses ocultos; dados pela LGPD em CSV e backup premium em JSON criptografado; conta gratuita com continuidade entre dispositivos; limites por plano aplicados também no servidor; hábitos escolhidos pelo usuário; registro e histórico simples; relatório simples gratuito; progresso visual; recomendações transparentes baseadas em regras; conteúdo informado por pesquisa.

Hipóteses ainda a validar: limite de 1 hábito e 1 registro por dia no gratuito; suficiência de 30 hábitos e 5 registros por dia no premium; atratividade do premium sem a sincronização como diferencial; periodicidade e preços; relatórios avançados ou jornadas guiadas; custo operacional das contas gratuitas. Não tratar essas hipóteses como autorização de implementação.
