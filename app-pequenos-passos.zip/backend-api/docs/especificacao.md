# Pequenos Passos API — especificação técnica

Este documento define as decisões técnicas da API backend. As regras de negócio estão em [docs/](../../docs/), principalmente em [planos e limites](../../docs/produto/planos-e-limites.md) e [notificações e registro rápido](../../docs/produto/notificacoes-e-registro-rapido.md). A implementação começa na etapa 6 do [roadmap](../../docs/roadmap.md), junto com a aplicação web.

Itens marcados como *proposta* são decisões iniciais a confirmar na preparação técnica.

## 1. Objetivo

- Permitir que uma pessoa com conta acompanhe seus hábitos e registros pela aplicação web e, depois, também pelo aplicativo Android.
- Aplicar os limites de cada plano no servidor, protegendo o serviço contra uso abusivo.
- Gerenciar a assinatura premium, com pagamento simulado até a etapa de pagamentos reais.
- Entregar os dados da pessoa pela LGPD em CSV e, no premium, gerar e importar backups criptografados.
- Receber com segurança os dados registrados offline no Android, sem perda nem duplicação.

## 2. Tecnologias

| Item | Escolha | Motivo |
|---|---|---|
| Linguagem | Java, versão LTS atual no início da implementação | Já prevista na visão do produto; ecossistema maduro e conhecido pela equipe. |
| Framework | Spring Boot (Web MVC, Security, Data JPA, Validation, Actuator) | Cobre API REST, autenticação, persistência e saúde do serviço sem bibliotecas avulsas. |
| Banco de dados | PostgreSQL | Relacional, transacional e adequado a dados estruturados como hábitos e registros. |
| Migrações | Flyway | Esquema versionado e reproduzível em todos os ambientes. |
| Build | Maven | *Proposta.* Padrão do ecossistema Java; pode ser trocado por Gradle se a equipe preferir alinhar com o Android. |
| Contrato | OpenAPI gerado a partir do código (springdoc-openapi) | Referência única para os clientes web e Android. |
| Tarefas agendadas | Agendamento do próprio Spring | Renovação e expiração de assinaturas, remoção de hábitos arquivados e avisos por e-mail, sem infraestrutura extra. |
| Criptografia | APIs padrão do Java (JCA), AES-256-GCM | Backup criptografado sem bibliotecas adicionais. |
| Testes | JUnit 5 e Testcontainers com PostgreSQL | Regras de limite, concorrência e remoção precisam ser testadas contra o banco real. |
| Empacotamento | Imagem de contêiner | Independe do provedor de hospedagem, que ainda não foi escolhido. |

## 3. Arquitetura

Camadas, de fora para dentro:

1. **API:** controladores REST, validação de entrada e conversão para o formato de erro padrão.
2. **Aplicação:** casos de uso (criar hábito, registrar, assinar, cancelar, exportar, importar, sincronizar), transações e autorização por dono do dado.
3. **Domínio:** regras de negócio puras, como limites de plano, contagem de registros por dia, transições de plano e datas de remoção. Sem dependência de Spring ou do banco, para testes rápidos.
4. **Persistência e integrações:** repositórios JPA, migrações Flyway, envio de e-mail e o provedor de pagamento.

Toda consulta é filtrada pela conta autenticada. Nenhum endpoint aceita o identificador do dono como parâmetro.

## 4. Autenticação e conta

*Proposta.*

- Cadastro com e-mail e senha. Senhas armazenadas com hash forte (Argon2 ou BCrypt, via Spring Security).
- Confirmação do e-mail e recuperação de senha por e-mail. Ambas exigem um serviço de envio de e-mail, ainda não escolhido, que também envia os avisos de remoção.
- **Access token** de curta duração (JWT, cerca de 15 minutos) e **refresh token** rotativo de longa duração, guardado no banco apenas como hash e revogável.
- **Web:** o refresh token é entregue em cookie `HttpOnly`, `Secure`, `SameSite=Strict`; o access token fica apenas em memória.
- **Android:** os tokens são entregues no corpo da resposta e guardados conforme [modo com conta e sincronização](../../android-app/docs/arquitetura/modo-conta-e-sincronizacao.md).
- Logout revoga o refresh token. Troca de senha revoga todas as sessões.
- Exclusão de conta remove hábitos, registros, sessões, assinatura, arquivos de exportação pendentes e dados de perfil. O prazo de expiração de cópias de segurança do provedor deve ser informado na política de privacidade.
- Login com provedores externos (Google e outros) é evolução posterior.

## 5. Recursos da API

Prefixo `/api/v1`. Formato JSON. Erros no formato *Problem Details* (RFC 9457), com um campo `code` estável para os clientes.

| Recurso | Operações | Etapa |
|---|---|---|
| `/auth` | `register`, `login`, `refresh`, `logout`, `verify-email`, `password-reset` | 7 |
| `/me` | consultar e alterar perfil e preferências; `DELETE` exclui a conta | 7 |
| `/me/plan` | plano atual, limites e uso atual (hábitos ativos, registros do dia) | 7 |
| `/me/subscription` | consultar; `POST` assina; `POST /cancel` cancela ao fim do período; `POST /resume` desfaz o cancelamento antes do fim | 7 |
| `/me/active-habit` | `GET` informa se a escolha está pendente e lista os candidatos; `POST` registra a escolha, aceita uma única vez por mudança de plano | 7 |
| `/me/data-requests` | `POST` solicita os dados pela LGPD; `GET` consulta o andamento e o link de download | 7 |
| `/habits` | listar, criar, consultar, alterar, excluir | 7 |
| `/habits/{id}/archive` e `/unarchive` | arquivar e reativar, respeitando o limite de hábitos ativos | 7 |
| `/habits/{id}/logs` | listar por período | 7 |
| `/habits/{id}/logs/{logId}` | `PUT` cria ou atualiza o registro com identificador gerado pelo cliente; `DELETE` exclui | 7 |
| `/reports/daily` | relatório simples: estado de cada hábito por dia em um período | 7 |
| `/sync/changes` | alterações desde um marcador, incluindo exclusões | 10 |
| `/backups` | `POST` gera um backup; `POST /import` importa um backup | 11 |

O `PUT` com identificador do cliente torna a gravação de registros idempotente: cliques repetidos, toques repetidos na notificação e reenvios da fila offline resultam no mesmo registro.

## 6. Aplicação dos limites

- Os valores de cada plano vêm de [planos e limites](../../docs/produto/planos-e-limites.md) e ficam em um único ponto do domínio, nunca espalhados pelos controladores.
- Criar hábito, reativar hábito, criar registro e importar backup verificam o limite dentro da mesma transação que grava o dado. A verificação bloqueia a linha da conta ou do hábito (`SELECT ... FOR UPDATE`) para que duas requisições simultâneas não ultrapassem o limite.
- Atualizar um registro existente não consome limite.
- A contagem diária usa a data local do registro informada pelo cliente, validada contra o fuso horário enviado (rejeitando datas futuras além de um dia de tolerância).
- Recusas por limite retornam `409 Conflict` com `code` `PLAN_LIMIT_ACTIVE_HABITS` ou `PLAN_LIMIT_DAILY_LOGS` e os valores do limite, para que os clientes expliquem a situação sem culpa.

## 7. Assinatura e pagamento simulado

Até a etapa 13 do roadmap, todo pagamento é simulado e sempre aprovado.

- O domínio depende de uma interface única de provedor de pagamento (por exemplo, `PaymentGateway`). A implementação inicial, `SimulatedPaymentGateway`, aprova toda cobrança sem contatar nenhum serviço externo.
- O provedor ativo é escolhido por configuração. A troca pelo provedor real na etapa 13 não deve alterar as regras de plano, a assinatura nem as transições.
- A assinatura registra estado (ativa, cancelada ao fim do período, expirada), início e fim do período, renovação automática e o provedor usado (`simulated`).
- *Proposta:* período mensal. A duração é configurável, para que os testes possam simular expirações em minutos.
- Uma tarefa agendada processa os fins de período: renova as assinaturas não canceladas (com o provedor simulado, sempre com sucesso) e expira as canceladas, executando a mudança para o gratuito descrita abaixo.
- As respostas de assinatura informam que o pagamento é simulado, para que os clientes mostrem esse aviso.
- Preços não estão definidos; o provedor simulado não registra valores cobrados.

### Mudança para o gratuito

Conforme [planos e limites](../../docs/produto/planos-e-limites.md#cancelar-ou-deixar-expirar-o-premium).

**Na expiração da assinatura**, em uma única transação:

1. Muda o plano da conta para gratuito e marca a escolha do hábito como pendente.
2. Agenda a data de remoção (data da mudança mais 3 meses) para todos os hábitos da conta.
3. Registra a mudança na sequência de alterações, para que os clientes atualizem as telas.

**Enquanto a escolha estiver pendente**, as operações sobre hábitos e registros retornam `409 Conflict` com `code` `ACTIVE_HABIT_CHOICE_REQUIRED`. Continuam disponíveis autenticação, perfil, assinatura, solicitação de dados pela LGPD e exclusão de conta.

**Ao receber a escolha** (`POST /me/active-habit`), em uma única transação:

1. Mantém o hábito escolhido ativo e limpa sua data de remoção.
2. Marca todos os demais como ocultados (`hidden_reason = PLAN_DOWNGRADE`), mantendo a data de remoção já agendada.
3. Encerra a escolha pendente. Uma nova chamada retorna `409 Conflict` com `code` `ACTIVE_HABIT_ALREADY_CHOSEN`.

**Regras de ocultação:**

- Hábitos ocultados não aparecem em nenhum endpoint de leitura (listagem, relatórios, sincronização), exceto na solicitação de dados pela LGPD.
- Nenhuma operação permite reativar, desarquivar ou registrar em um hábito ocultado enquanto a conta estiver no gratuito. A recusa vale para qualquer cliente, não só para as interfaces oficiais.
- Ao assinar novamente antes da remoção, os hábitos ocultados passam a arquivados, voltam a aparecer e perdem a data de remoção.
- *Proposta:* se a escolha não for feita até a data de remoção, a tarefa de remoção mantém o hábito com o registro mais recente e remove os demais.

## 8. Remoção de hábitos ocultados

- Uma tarefa agendada diária remove definitivamente os hábitos ocultados cuja data de remoção já passou, junto com seus registros e histórico de metas.
- A tarefa é idempotente e processa em lotes pequenos, para não bloquear o banco.
- Os aparelhos Android já apagam a cópia local no momento da ocultação (ver seção 13); a remoção definitiva não exige nova sincronização.
- *Proposta:* outra tarefa diária envia os avisos por e-mail 30 e 7 dias antes da remoção, registrando o envio para não repetir avisos.
- Os logs da tarefa registram quantidades e identificadores técnicos, nunca nomes de hábitos ou observações.

## 9. Solicitação de dados pela LGPD (CSV)

- Disponível para qualquer conta, em qualquer plano.
- A geração é assíncrona: a solicitação é registrada, o arquivo é montado em segundo plano e a pessoa baixa pela aplicação quando estiver pronto.
- *Proposta de formato:* um arquivo ZIP com um CSV por tipo de dado (`conta.csv`, `assinatura.csv`, `habitos.csv`, `metas.csv`, `registros.csv`), em UTF-8 com BOM e separador ponto e vírgula, para abrir corretamente em planilhas configuradas em português.
- O download exige autenticação, expira em 7 dias e o arquivo é apagado depois disso.
- *Proposta:* no máximo uma solicitação a cada 24 horas por conta, para evitar abuso.
- Nenhum endpoint importa CSV. O arquivo é somente para consulta.

## 10. Backup e importação (JSON criptografado)

Recurso premium da etapa 11.

### Formato do arquivo

```json
{
  "format": "pequenos-passos-backup",
  "formatVersion": 1,
  "createdAt": "2027-01-15T12:00:00Z",
  "keyId": "backup-key-2027-01",
  "algorithm": "AES-256-GCM",
  "nonce": "<base64>",
  "ciphertext": "<base64>"
}
```

- O conteúdo (`ciphertext`) é um JSON compactado com hábitos, histórico de metas e registros, com versão de esquema própria.
- A criptografia autenticada (AES-256-GCM) impede a leitura e detecta qualquer alteração no arquivo.
- Os campos `format`, `formatVersion`, `keyId` e o identificador da conta entram como dados associados autenticados. Assim, o backup só é aceito na conta que o gerou (*proposta* de [planos e limites](../../docs/produto/planos-e-limites.md#backup-e-importação-premium)).

### Chaves

- A chave de 256 bits fica no gerenciador de segredos do provedor de hospedagem, nunca no repositório, no banco ou nos logs.
- O `keyId` permite trocar a chave periodicamente; chaves antigas continuam disponíveis só para leitura dos backups já emitidos.
- Perder a chave torna todos os backups ilegíveis. A chave precisa de cópia de segurança e procedimento de recuperação documentados antes de liberar o recurso.

### Importação

1. Verifica se a conta é premium e se o arquivo não ultrapassa 5 MB.
2. Descriptografa e valida a autenticação; arquivos alterados, de outra conta ou com chave desconhecida retornam `422` com `code` `BACKUP_INVALID`.
3. Valida o esquema do conteúdo e os tamanhos de campo, como em qualquer gravação.
4. Em uma transação, cria hábitos e registros que não existam na conta, identificados pelos UUIDs; itens já existentes são mantidos como estão.
5. Aplica os limites do plano; se a importação ultrapassar um limite, nada é gravado e a resposta informa o limite.

## 11. Proteção contra abuso

*Valores iniciais de proposta, a calibrar com métricas.*

| Proteção | Valor inicial |
|---|---|
| Requisições autenticadas por conta | 120 por minuto |
| Tentativas de login por e-mail e por IP | 5 por minuto, com bloqueio progressivo |
| Cadastros por IP | 5 por hora |
| Tamanho do corpo da requisição | 64 KB (5 MB na importação de backup) |
| Nome do hábito | 80 caracteres |
| Descrição do hábito | 500 caracteres |
| Observação do registro | 1.000 caracteres |
| Itens por envio de sincronização | 200 |
| Solicitações de dados pela LGPD | 1 a cada 24 horas |
| Geração de backups | *a definir na etapa 11* |
| Total de hábitos armazenados por conta | ponto aberto em [planos e limites](../../docs/produto/planos-e-limites.md) |

O limite de requisições pode ser implementado na própria aplicação (por exemplo, com Bucket4j) ou na infraestrutura de hospedagem. A escolha depende do provedor e deve ser justificada na preparação técnica.

## 12. Modelo de dados

Tabelas iniciais, derivadas das estruturas conceituais da [visão do produto](../../docs/product-spec.md#6-plataformas-e-dados-conceituais):

- **user_account:** id, e-mail, hash da senha, nome, foto, plano, escolha de hábito pendente, fuso horário, preferências, e-mail confirmado, datas de criação e atualização.
- **refresh_token:** id, conta, hash do token, expiração, revogação, aparelho ou navegador de origem.
- **subscription:** id, conta, estado, provedor, início e fim do período, cancelamento ao fim do período, datas de criação e atualização.
- **habit:** id (UUID do cliente), conta, nome, descrição, categoria, unidade, meta, frequência, dias da semana, contexto, início, arquivado em, ocultado em, motivo da ocultação, data de remoção agendada, versão, datas de criação, atualização e exclusão.
- **habit_log:** id (UUID do cliente), hábito, conta, data local, status, quantidade, duração, observação, origem (notificação, Android, web, importação), horário da declaração, horário da atividade quando informado, versão, datas de criação, atualização e exclusão.
- **habit_goal_history:** hábito, meta, início e fim da vigência.
- **data_export_request:** id, conta, estado, local do arquivo, data de expiração.
- **removal_notice:** hábito, tipo de aviso (30 ou 7 dias), data de envio.
- **change_sequence:** número crescente associado a cada alteração, usado como marcador de sincronização.

Exclusões feitas pela pessoa são marcadas (`deleted_at`) e mantidas por tempo limitado para que os aparelhos sincronizem a remoção; depois, são removidas definitivamente. Datas e horários são gravados em UTC; a data local do registro é gravada como data sem horário.

## 13. Sincronização

Usada pelo aplicativo Android a partir da etapa 10; a web lê diretamente os recursos da API.

- Cada alteração aceita recebe um número da sequência de alterações da conta. O cliente envia o último número recebido e a API devolve tudo o que mudou depois dele.
- Cada entidade tem um número de versão. Uma alteração enviada com versão desatualizada retorna `409 Conflict` com a versão atual; o cliente decide conforme [modo com conta e sincronização](../../android-app/docs/arquitetura/modo-conta-e-sincronizacao.md).
- A migração do modo sem conta usa os mesmos endpoints de gravação, aplicando as regras de [planos e limites](../../docs/produto/planos-e-limites.md#criar-conta-a-partir-do-modo-sem-conta).
- Um hábito ocultado é enviado aos aparelhos como marcação de remoção, para que desapareça também da cópia local. Se a pessoa assinar novamente antes da remoção definitiva, o hábito e seus registros são reenviados.

## 14. Segurança e privacidade

- Somente HTTPS. CORS restrito à origem oficial da aplicação web.
- Proteção contra CSRF no endpoint de renovação por cookie.
- Dados criptografados em repouso pelo provedor de banco de dados.
- Logs sem senhas, tokens, e-mails completos, chaves ou conteúdo de observações.
- Arquivos da LGPD guardados com acesso restrito e apagados após a expiração.
- Procedimentos da LGPD e o prazo de remoção de hábitos arquivados a confirmar com orientação jurídica.

## 15. Operação

- Endpoints de saúde do Actuator para o provedor de hospedagem.
- Logs estruturados com identificador de requisição.
- Ambientes separados de desenvolvimento, teste e produção, com bancos e chaves independentes.
- Em produção, a API registra no início se o provedor de pagamento ativo é o simulado, para que isso nunca passe despercebido.

## 16. Testes

- Testes unitários das regras de domínio: limites por plano, contagem por dia, correção sem consumo de limite, escolha do hábito ativo, cálculo da data de remoção, recusa de uma segunda escolha e de reativação de hábito ocultado no gratuito.
- Testes de integração com Testcontainers: concorrência na verificação de limites, idempotência do `PUT` de registros, renovação e expiração de assinatura com período curto, bloqueio enquanto a escolha estiver pendente, ocultação nos endpoints de leitura, remoção de hábitos ocultados, geração do CSV, isolamento entre contas.
- Testes do backup: arquivo alterado, arquivo de outra conta, chave rotacionada, importação que ultrapassa o limite, importação repetida sem duplicação.
- Testes de segurança dos fluxos de autenticação: expiração, rotação e revogação de tokens.

## 17. Fora do escopo inicial

- Pagamentos reais (etapa 13). Assinaturas compradas no Android provavelmente exigirão o sistema de cobrança da Google Play; a web exigirá um provedor de pagamento. A decisão fica para essa etapa.
- Backup, importação e relatórios avançados (etapa 11).
- Sincronização com o Android (etapa 10).
- Envio de notificações pelo servidor (push).
- Login com provedores externos.

## 18. Pontos abertos

- Provedor de hospedagem, de banco de dados gerenciado e de gerenciamento de segredos.
- Serviço de envio de e-mail.
- Formato final do CSV da LGPD (ZIP com vários CSV ou um único CSV).
- Teto de hábitos armazenados por conta.
- Local de aplicação do limite de requisições (aplicação ou infraestrutura).
- Prazo de retenção das marcações de exclusão e das cópias de segurança do provedor.
- Duração do período da assinatura simulada.
