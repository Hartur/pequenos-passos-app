# Pequenos Passos API — instruções para agentes

Leia primeiro as [instruções gerais do repositório](../AGENTS.md). Este arquivo acrescenta o que é específico da API backend. As regras de negócio ficam em [docs/](../docs/) e não devem ser repetidas aqui; a especificação técnica está em [docs/especificacao.md](docs/especificacao.md).

## Papel da API

- Guardar os dados das contas e servir o [aplicativo Android](../android-app/AGENTS.md) e a [aplicação web](../web-app/AGENTS.md).
- Aplicar os limites de [planos e limites](../docs/produto/planos-e-limites.md). A API é a proteção definitiva contra uso abusivo; nunca confie apenas na validação dos clientes.

## Tecnologias e limites

- Java (versão LTS atual), Spring Boot, Spring Security, Spring Data JPA, PostgreSQL, Flyway e Maven.
- Regras de negócio (limites, transições de plano, recomendações) ficam em serviços de domínio testáveis, sem depender de controladores nem do banco.
- Toda alteração de esquema é feita por migração Flyway versionada; nunca altere uma migração já aplicada.
- O contrato da API é documentado em OpenAPI e é a referência para os clientes Android e web.
- Pagamentos usam apenas o provedor simulado, que sempre aprova, até a etapa de pagamentos reais do [roadmap](../docs/roadmap.md). Nunca acople regras de plano ao provedor de pagamento.
- Não introduza sincronização, backup, importação ou relatórios avançados antes das etapas correspondentes do roadmap.
- Chaves de criptografia de backup vêm do gerenciador de segredos; nunca as grave em código, banco ou logs.
- Remoções definitivas de dados (hábitos ocultados após o prazo, exclusão de conta) precisam de testes de integração que comprovem que nada além do previsto é removido.
- Nunca registre senhas, tokens ou dados pessoais em logs. Segredos vêm de variáveis de ambiente, nunca do repositório.
- Ao alterar regras de limite, autenticação ou sincronização, escreva testes de integração com PostgreSQL real.
