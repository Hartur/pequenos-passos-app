# Pequenos Passos — instruções para agentes

## Estrutura do repositório

| Pasta | Conteúdo |
|---|---|
| [docs/](docs/) | Regras de negócio, visão, planos, telas e roadmap, comuns a todas as aplicações. Sem decisões de tecnologia. |
| [backend-api/](backend-api/AGENTS.md) | API backend (primeira versão): instruções e especificação técnica. |
| [web-app/](web-app/AGENTS.md) | Aplicação web (primeira versão): instruções e especificação técnica. |
| [android-app/](android-app/AGENTS.md) | Aplicativo Android (depois da web): instruções, arquitetura e planejamento específicos. |

Ao trabalhar em uma aplicação, leia este arquivo e também o `AGENTS.md` da pasta dela. Em caso de conflito, as instruções da pasta da aplicação prevalecem para aquela aplicação.

## Documentação e escopo

- Consulte [a visão e especificação do produto](docs/product-spec.md) para princípios, funcionalidades planejadas, evidências e hipóteses comerciais.
- Consulte [planos e limites](docs/produto/planos-e-limites.md) para limites de hábitos e registros, regras de conta e transições entre planos.
- Consulte [o roadmap](docs/roadmap.md) antes de iniciar uma etapa; implemente somente o escopo autorizado e priorizado para ela.
- Para notificações e registro rápido, siga os documentos específicos: [regras de produto](docs/produto/notificacoes-e-registro-rapido.md), [restrições técnicas](android-app/docs/arquitetura/notificacoes-e-persistencia-local.md) e [critérios e priorização do MVP](android-app/docs/planejamento/mvp-notificacoes-e-registro-rapido.md).
- As regras de produto (em `docs/`) definem o comportamento esperado; os documentos de arquitetura e especificação técnica (nas pastas das aplicações) definem restrições técnicas; os documentos de planejamento definem escopo e validação. Evite repetir especificações: atualize o documento responsável e mantenha os demais como referências.
- Regras de negócio não pertencem às pastas das aplicações, e decisões de tecnologia não pertencem a `docs/`.

## Contexto e objetivo

Pequenos Passos ajuda pessoas a desenvolver hábitos e habilidades por meio de pequenas ações, acompanhamento consistente e recomendações baseadas em evidências científicas. O produto é composto por uma API backend e uma aplicação web, que formam a primeira versão e permitem acompanhar os dados de qualquer lugar com uma conta, e por um aplicativo Android, que vem em seguida e também funciona offline sem conta. O produto deve evoluir incrementalmente, priorizando simplicidade, confiabilidade, privacidade e validação com usuários reais. Não implemente funcionalidades futuras só por estarem previstas na visão.

## Limites gerais

- Separe interface, regras de negócio e persistência em todas as aplicações. Mantenha recomendações independentes da interface.
- Os limites de plano são aplicados pela API; as interfaces os explicam, mas não são a única proteção.
- Prefira soluções simples, testáveis e sem abstrações ou dependências desnecessárias; justifique novas bibliotecas.
- Não introduza funcionalidades fora da etapa autorizada no roadmap. Em especial, pagamentos reais só entram na etapa própria; até lá, o pagamento é simulado e sempre aprovado.

## Princípios de produto

- O usuário controla hábitos, metas, lembretes e registros; recomendações são transparentes, compreensíveis e ignoráveis.
- Ausência de registro não significa falha. Interrupções não apagam o progresso anterior. A única remoção automática de dados é a dos hábitos não escolhidos no fim do premium, que ficam ocultos e são removidos após 3 meses, com aviso, conforme [planos e limites](docs/produto/planos-e-limites.md).
- Não culpe ou envergonhe o usuário, não trate estimativas científicas como garantias universais e não invente evidências ou referências.

## Processo de implementação

1. Identifique o objetivo, os critérios de aceitação e o escopo autorizado no roadmap.
2. Inspecione a estrutura, os padrões existentes e a documentação relevante antes de alterar código.
3. Para tarefas com várias alterações, proponha um plano curto; implemente apenas o escopo acordado.
4. Ao alterar regras de negócio, escreva ou atualize testes. Execute os testes e verificações pertinentes antes de concluir e nunca afirme que passaram sem executá-los.
5. Atualize a documentação responsável quando o comportamento esperado mudar, sem duplicar especificações.
6. Resuma alterações, validações e limitações. Nunca inclua segredos, tokens ou credenciais no repositório.

Se uma decisão importante de produto ou arquitetura estiver indefinida e for difícil de reverter, apresente alternativas e solicite orientação antes de assumir o compromisso.
