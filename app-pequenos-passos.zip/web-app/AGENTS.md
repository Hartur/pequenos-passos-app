# Pequenos Passos Web — instruções para agentes

Leia primeiro as [instruções gerais do repositório](../AGENTS.md). Este arquivo acrescenta o que é específico da aplicação web. As regras de negócio ficam em [docs/](../docs/) e não devem ser repetidas aqui; a especificação técnica está em [docs/especificacao.md](docs/especificacao.md).

## Papel da aplicação

- Ser, junto com a API, a primeira versão do produto: pessoas com conta acompanham seus hábitos pelo navegador e, quando o aplicativo Android existir, veem os mesmos dados nele.
- Funciona sempre online e consome exclusivamente a [API backend](../backend-api/docs/especificacao.md). Não existe modo sem conta na web.

## Tecnologias e limites

- Angular (versão estável atual) com TypeScript em modo estrito, componentes standalone e signals.
- Angular Router, Reactive Forms tipados, HttpClient e Angular Material com tema próprio da [identidade visual](../docs/identidade%20visual/).
- Estado em serviços com signals; não introduza bibliotecas de estado global sem justificativa.
- Gráficos do relatório simples feitos com SVG em componentes próprios; uma biblioteca de gráficos só entra com os relatórios avançados, com justificativa.
- Limites de plano são exibidos pela interface, mas decididos pela API. Trate as recusas da API em vez de duplicar regras.
- Tokens nunca vão para `localStorage` ou `sessionStorage`.
- A contratação do premium usa o pagamento simulado da API e deve informar claramente que nenhuma cobrança é feita. Não integre provedores de pagamento antes da etapa de pagamentos reais do [roadmap](../docs/roadmap.md).
- Não introduza lembretes, escrita offline, backup, importação ou relatórios avançados antes das etapas correspondentes do roadmap.
- Toda tela deve funcionar em celular e desktop, por teclado e com leitor de tela.
