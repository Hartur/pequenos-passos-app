# Pequenos Passos Web — especificação técnica

Este documento define o escopo e as decisões técnicas da aplicação web. As regras de negócio estão em [docs/](../../docs/), principalmente em [telas e interações](../../docs/produto/telas-e-interacoes.md), [planos e limites](../../docs/produto/planos-e-limites.md) e [notificações e registro rápido](../../docs/produto/notificacoes-e-registro-rapido.md) (regras de registro e complementação). A implementação começa na etapa 6 do [roadmap](../../docs/roadmap.md), junto com a API: a web é a primeira interface do produto.

Itens marcados como *proposta* são decisões iniciais a confirmar na preparação técnica.

## 1. Objetivo

Permitir que uma pessoa com conta, gratuita ou premium, acompanhe seus hábitos de qualquer computador ou celular com navegador. Quando o aplicativo Android existir, a web mostrará e alterará os mesmos dados registrados nele.

Características:

- **Exige conta.** O modo sem conta existe apenas no Android.
- **Sempre online.** A fonte dos dados é a [API backend](../../backend-api/docs/especificacao.md); a web não guarda dados de hábitos no navegador.
- **Mesmas regras.** Conteúdo e estados das telas seguem [telas e interações](../../docs/produto/telas-e-interacoes.md); a web adapta apenas a disposição visual.

## 2. Escopo da primeira versão (etapa 7)

| Área | Incluído |
|---|---|
| Acesso | Cadastro, login, confirmação de e-mail, recuperação de senha, sair da conta |
| Hoje | Hábitos do dia em foco, seletor de dia, resumo, registro com um clique, complementação opcional (quantidade, duração, observação), registro parcial quando o hábito admitir, contagem de registros do dia no premium |
| Hábitos | Listar, criar, editar, edição rápida no card (dias e duração), remover vários com confirmação, arquivar, reativar e consultar arquivados |
| Registros | Relatório simples semanal, mensal e anual, com a legenda registrado, parcial e sem registro |
| Assinatura | Assinar o premium com pagamento simulado, ver até quando vale, cancelar e desfazer o cancelamento; após o fim do premium, informar quantos hábitos estão guardados e até quando |
| Escolha do hábito | Tela obrigatória de escolha de 1 hábito após o fim do premium, conforme [telas e interações](../../docs/produto/telas-e-interacoes.md#escolha-do-hábito-após-o-fim-do-premium) |
| Mais | Perfil (nome, senha, foto), plano atual com limites e uso, solicitação e download dos dados pela LGPD (CSV), excluir conta |
| Limites | Mensagens neutras quando um limite do plano for atingido, a partir das respostas da API |

Etapa 11: gerar e baixar o backup criptografado, enviar um backup para importação e relatórios avançados.

Fora das etapas 7 e 11:

- Lembretes e notificações no navegador.
- Uso offline com registro sem conexão.
- Pagamentos reais (etapa 13).
- Modo escuro e outros idiomas além do português do Brasil.

### Contratação com pagamento simulado

- A tela de contratação mostra, antes da confirmação, um aviso claro de que o pagamento é simulado e nenhuma cobrança é feita.
- A tela não pede dados de cartão nem outros dados de pagamento.
- Ao confirmar, a API aprova a assinatura e a web atualiza o plano e os limites sem recarregar a página.
- A tela de contratação fica isolada em um componente próprio, para ser trocada pelo fluxo do provedor real na etapa 13.

## 3. Escolha da tecnologia

### Critérios

1. **Curva de aprendizado** para quem vai desenvolver, que tem pouca experiência com frontend, mas já usou Angular.
2. **Menos decisões e dependências:** o produto pede poucas bibliotecas e soluções padronizadas (diretriz geral do repositório).
3. **Adequação às telas:** formulários com validação, listas com edição rápida, seleção múltipla, gráficos simples, rotas protegidas por login.
4. **Integração com a API Spring Boot:** autenticação com renovação de sessão, tratamento de erros padronizado, contrato OpenAPI.
5. **Manutenção a longo prazo:** suporte, documentação em português e inglês, atualizações previsíveis.

### Comparação

| Opção | A favor | Contra | Decisão |
|---|---|---|---|
| **Angular** | Já conhecido pelo desenvolvedor. Roteamento, formulários, HTTP, testes, internacionalização e PWA são oficiais do framework. Estrutura com serviços e injeção de dependência parecida com Spring. TypeScript estrito por padrão. Calendário de versões previsível com períodos de suporte. | Mais conceitos iniciais que React ou Vue; pacote inicial um pouco maior. | **Escolhida** |
| React (com Vite) | Maior ecossistema e comunidade. | É uma biblioteca de interface: rotas, formulários, chamadas HTTP e estrutura exigem escolher bibliotecas de terceiros, o que pesa para quem tem pouca experiência. Sem experiência prévia da equipe. | Descartada |
| Vue | Curva de entrada suave e boa documentação. | Ecossistema e mercado menores que os do Angular e do React; sem experiência prévia da equipe. | Descartada |
| Kotlin com Compose Multiplatform para web | Compartilharia linguagem e parte do código com o Android. | O alvo web é bem menos maduro que o Android, com ecossistema, acessibilidade e indexação mais limitados; aumentaria o risco da primeira versão. | Descartada; pode ser reavaliada no futuro |
| Páginas renderizadas pelo servidor (Spring com Thymeleaf) | Menos um projeto e menos uma tecnologia. | Interações como edição rápida, seleção múltipla e gráficos ficam mais trabalhosas; mistura interface com a API; dificulta transformar a web em PWA depois. | Descartada |

### Pilha escolhida

| Item | Escolha | Motivo |
|---|---|---|
| Framework | Angular, versão estável atual, com componentes standalone e signals | Forma recomendada atualmente pelo próprio Angular; menos código de configuração. |
| Linguagem | TypeScript em modo estrito | Erros de tipo detectados antes da execução. |
| Rotas | Angular Router, com carregamento sob demanda por área e guardas de autenticação | Oficial do framework. |
| Formulários | Reactive Forms tipados | Validação de cadastro de hábito, perfil e complementação. |
| HTTP | HttpClient com interceptadores para autenticação, renovação de sessão e erros | Oficial do framework; centraliza o tratamento das respostas da API. |
| Componentes | Angular Material (Material 3) e CDK, com tema próprio | Componentes acessíveis (diálogos, menus, seletores de data, campos) sem construir do zero; o tema aplica a identidade visual. |
| Gráficos | SVG em componentes próprios | O relatório simples tem barras por dia; não justifica uma biblioteca. Uma biblioteca será avaliada com os relatórios avançados. |
| Estado | Serviços por área com signals | A aplicação é pequena; uma biblioteca de estado global seria complexidade desnecessária. |
| Cliente da API | Tipos e serviços gerados a partir do OpenAPI da API | *Proposta.* Evita divergência entre web e API. Alternativa: tipos escritos à mão, aceitável no início. |
| Testes unitários | Executor padrão do Angular CLI | Sem configuração extra. |
| Testes de ponta a ponta | Playwright | Testa os fluxos principais em navegadores reais e em tamanho de celular. |
| Qualidade | angular-eslint e Prettier | Padrão de código verificado automaticamente. |
| Ambiente | Node.js LTS e npm | Padrão do Angular CLI. |
| PWA | Service worker do Angular | *Proposta.* Permite instalar a web no celular ou computador e carregar a interface mais rápido. Não guarda dados de hábitos nem permite registrar sem conexão. Pode ficar para depois da primeira versão. |

## 4. Organização do código

*Proposta.*

```
web-app/
  src/app/
    core/        autenticação, interceptadores, tratamento de erros, layout principal
    api/         cliente gerado a partir do OpenAPI
    features/
      auth/      cadastro, login, recuperação de senha
      hoje/
      habitos/
      registros/
      assinatura/
      mais/      perfil, meus dados (LGPD), excluir conta
    shared/      componentes visuais reutilizáveis (card de hábito, legenda, gráficos SVG)
```

Cada área tem seus componentes, rotas e serviço de dados. Componentes só exibem e capturam interação; chamadas à API e preparação dos dados ficam nos serviços. Regras de negócio permanecem na API.

## 5. Layout responsivo

| Largura da janela | Navegação | Disposição |
|---|---|---|
| Até 599 px | Barra inferior com Hoje, Hábitos, Registros e Mais | Uma coluna, como no Android |
| 600 a 1.239 px | Trilho lateral com ícones e rótulos | Uma coluna mais larga |
| A partir de 1.240 px | Menu lateral fixo | Conteúdo principal com painel complementar (por exemplo, Hoje com o resumo da semana ao lado) |

Os intervalos seguem as classes de tamanho do Material 3 e são detectados com o `BreakpointObserver` do CDK.

## 6. Identidade visual

Seguir a [identidade visual](../../docs/identidade%20visual/) do produto: roxo como cor principal, cards claros com cantos arredondados, uma cor e um ícone por categoria de hábito, e verde para o estado concluído. As cores, tipografia e raios ficam definidos uma única vez no tema do Angular Material e em variáveis CSS, nunca repetidos nos componentes.

## 7. Comportamentos técnicos

### Autenticação

- O access token fica apenas em memória. A sessão é renovada pelo cookie `HttpOnly` emitido pela API, conforme a [especificação da API](../../backend-api/docs/especificacao.md#4-autenticação-e-conta).
- Ao receber `401`, o interceptador tenta renovar a sessão uma vez e repete a requisição. Se não conseguir, leva ao login e volta para a mesma página depois.
- Rotas internas são protegidas por guardas; rotas de acesso redirecionam quem já está logado.
- Enquanto a escolha do hábito estiver pendente, um guarda leva qualquer rota de hábitos e registros para a tela de escolha. A resposta `409` com `code` `ACTIVE_HABIT_CHOICE_REQUIRED` também leva a essa tela, cobrindo a mudança de plano com a página já aberta.

### Dados e concorrência

- Ao voltar para a aba ou recuperar a conexão, a tela recarrega os dados, porque outra aba ou, futuramente, o Android pode ter alterado algo.
- Novos registros recebem identificador UUID gerado no navegador (`crypto.randomUUID()`). Cliques repetidos resultam no mesmo registro.
- Resposta `409` por versão desatualizada: a tela recarrega o item e informa que ele foi alterado em outro aparelho.
- Resposta `409` por limite de plano: a tela mostra a mensagem neutra correspondente, conforme [planos e limites](../../docs/produto/planos-e-limites.md#3-como-os-limites-são-contados).
- Sem conexão: um aviso discreto informa que é preciso estar online para registrar; nada é registrado localmente.

### Datas

A data de um registro é o dia local do navegador. A web envia a data local e o fuso horário à API. As datas são exibidas com o formato `pt-BR`.

### Acessibilidade

- Meta: WCAG 2.2 nível AA.
- Estados nunca são indicados apenas por cor: concluído, parcial e sem registro também têm ícone e texto.
- No modo **Remover vários**, cada card é um botão que pode ser selecionado por teclado (Enter ou Espaço) e informa seu estado de seleção a leitores de tela.
- Respeitar a preferência do sistema por menos animações.

### Segurança

- Política de segurança de conteúdo (CSP) restritiva no servidor que entrega a aplicação.
- Não contornar a sanitização do Angular para inserir HTML.
- Web e API sob o mesmo domínio principal (por exemplo, `app.` e `api.` do mesmo domínio), para que o cookie de sessão com `SameSite=Strict` funcione.

## 8. Publicação

O resultado do build é um conjunto de arquivos estáticos, publicado em hospedagem estática ou CDN, com HTTPS e redirecionamento de rotas para `index.html`. O provedor ainda não está definido e deve ser escolhido junto com o da API.

## 9. Testes

- Testes unitários dos serviços de cada área e dos componentes com lógica de exibição (estados do card, legenda, gráficos).
- Testes de ponta a ponta com Playwright para cadastro, login, criação de hábito, registro, complementação, remoção de vários, mensagens de limite, contratação e cancelamento do premium simulado, escolha do hábito ativo e solicitação de dados pela LGPD, em tamanho de desktop e de celular.
- Verificação automática de acessibilidade nos testes de ponta a ponta.

## 10. Pontos abertos

- Incluir ou não o PWA na primeira versão.
- Gerar o cliente da API a partir do OpenAPI ou escrever os tipos à mão.
- Provedor de hospedagem e domínio.
- Lembretes na web (notificações do navegador), avaliados após a primeira versão.
