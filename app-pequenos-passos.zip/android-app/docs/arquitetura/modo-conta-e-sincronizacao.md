# Modo com conta e sincronização

Este documento registra as restrições técnicas do aplicativo Android quando a pessoa usa uma conta. As regras de negócio de conta, limites e transições estão em [planos e limites](../../../docs/produto/planos-e-limites.md); o contrato do servidor está na [especificação da API](../../../backend-api/docs/especificacao.md).

Este documento se aplica à versão inicial do Android (etapa 10 do [roadmap](../../../docs/roadmap.md)), que já nasce com os modos sem conta e com conta. Quando ela for desenvolvida, a API e a web já estarão em uso.

## Princípios

- **Offline primeiro:** toda ação é gravada no Room imediatamente. A interface lê sempre do banco local; a rede nunca bloqueia um registro.
- **Servidor como fonte de verdade da conta:** o aparelho guarda uma cópia; quando houver divergência, prevalece o que o servidor aceitou.
- **Nada se perde em silêncio:** se o servidor recusar uma alteração, o aplicativo mantém o dado local e explica o que aconteceu.

## Identificadores

Hábitos e registros recebem um identificador UUID gerado no próprio aparelho no momento da criação, inclusive no modo sem conta. Isso permite enviar dados criados offline, repetir envios sem duplicar e migrar os dados do modo sem conta para a conta.

## Envio de alterações

- Cada alteração local de conta fica marcada como pendente até a API confirmar.
- O envio usa WorkManager com restrição de rede, novas tentativas e espera crescente entre elas.
- Cada envio de registro leva o identificador do cliente; a API trata reenvios como a mesma operação.
- A tela Mais mostra o estado da sincronização (sincronizado, pendente, indisponível), conforme [telas e interações](../../../docs/produto/telas-e-interacoes.md).

## Recebimento de alterações

- O aplicativo pede à API apenas o que mudou desde a última sincronização, usando o marcador devolvido pela própria API.
- Exclusões chegam como marcações de remoção, para que o aparelho também apague a cópia local. Isso inclui os hábitos ocultados no fim do premium, que devem sumir do aparelho assim que a pessoa escolher o hábito que segue, conforme [planos e limites](../../../docs/produto/planos-e-limites.md#cancelar-ou-deixar-expirar-o-premium). Enquanto a escolha estiver pendente, o aplicativo mostra a tela de escolha e não aceita novos registros; registros offline pendentes de hábitos que forem ocultados são mostrados à pessoa antes de serem descartados.
- A sincronização acontece ao abrir o aplicativo, após registros e periodicamente em segundo plano, respeitando as restrições de bateria do Android.

## Conflitos e recusas

*Decisões de proposta, a validar na preparação técnica.*

- **Mesma entidade alterada no Android e na web:** prevalece a última alteração aceita pelo servidor. A API usa um número de versão por entidade para detectar alterações concorrentes.
- **Limite de plano recusado pelo servidor:** por exemplo, um registro feito offline no Android e outro feito na web para o mesmo hábito e o mesmo dia no plano gratuito. O registro local recusado não é apagado: o aplicativo mostra o conflito e oferece transformar o dado local em complementação do registro existente ou descartá-lo.
- **Hábito arquivado ou excluído em outro aparelho:** registros pendentes para ele são mostrados à pessoa antes de serem descartados.

## Autenticação no aparelho

- Os tokens da API ficam em armazenamento protegido pelo Android Keystore, nunca em texto puro ou em logs.
- Ao sair da conta, o aplicativo segue a regra de [planos e limites](../../../docs/produto/planos-e-limites.md#sair-da-conta-no-aplicativo-android): avisa sobre pendências, remove a cópia local da conta e volta ao modo sem conta.
- A sessão expirada não impede registrar offline; o aplicativo pede novo login apenas quando precisar sincronizar.

## Datas e fuso horário

A data de um registro é o dia local do usuário em que a atividade ocorreu. O aplicativo envia a data local e o fuso horário, além do horário da declaração, para que a API conte os limites diários corretamente.
