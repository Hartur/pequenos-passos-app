# Pequenos Passos Android — instruções para agentes

Leia primeiro as [instruções gerais do repositório](../AGENTS.md). Este arquivo acrescenta o que é específico do aplicativo Android. As regras de negócio ficam em [docs/](../docs/) e não devem ser repetidas aqui.

## Papel do aplicativo

- **Sem conta:** funciona totalmente offline, com os dados somente no aparelho, aplicando os limites do plano gratuito definidos em [planos e limites](../docs/produto/planos-e-limites.md).
- **Com conta:** continua funcionando offline, guarda uma cópia local e sincroniza com a [API backend](../backend-api/docs/especificacao.md) quando houver conexão.
- É a única plataforma com lembretes e notificações com ações no início do produto.

## Tecnologias e limites

- Kotlin, Jetpack Compose, Room com SQLite, ViewModel, StateFlow e Kotlin Coroutines.
- Android Studio é o ambiente de desenvolvimento previsto.
- Separe interface, regras de negócio e persistência. O registro sempre é salvo primeiro no Room; a sincronização acontece depois e nunca bloqueia o registro.
- Os limites do plano também são verificados localmente, para manter o comportamento offline igual ao online. A decisão final, com conta, é da API.
- O aplicativo é desenvolvido depois da API e da web (etapas 9 e 10 do [roadmap](../docs/roadmap.md)). Sua versão inicial já inclui os dois modos, sem conta e com conta, consumindo a API existente.
- Prefira soluções simples, testáveis e sem dependências desnecessárias; justifique novas bibliotecas.

## Documentação específica

- [Notificações e persistência local](docs/arquitetura/notificacoes-e-persistencia-local.md): restrições técnicas de lembretes, notificações e Room.
- [Modo com conta e sincronização](docs/arquitetura/modo-conta-e-sincronizacao.md): como o aplicativo convive com a API.
- [MVP de notificações e registro rápido](docs/planejamento/mvp-notificacoes-e-registro-rapido.md): critérios de aceitação e priorização.

## Interface

- Navegação inferior com os quatro destinos definidos em [telas e interações](../docs/produto/telas-e-interacoes.md).
- Siga a [identidade visual](../docs/identidade%20visual/) do produto.
